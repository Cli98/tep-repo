## library from python
import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"

import time
import numpy as np
import random
import sys

import warnings
warnings.filterwarnings("ignore", category=UserWarning)

import torch
from torch.utils.tensorboard import SummaryWriter
import torch.distributed as dist
import torch.utils.data.distributed
from tqdm import tqdm

## from user-define
from data_process.kitti_dataloader import create_train_dataloader, create_val_dataloader
from models.model_utils import create_model, make_data_parallel, get_num_parameters
from utils.train_utils import create_optimizer, create_lr_scheduler, get_saved_state, save_checkpoint
from utils.torch_utils import reduce_tensor, to_python_float
from utils.misc import AverageMeter, ProgressMeter
from config.train_config import parse_train_configs
from losses.losses import Compute_Loss

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def main():
    configs = parse_train_configs()
    if configs.seed is not None:
        set_seed(configs.seed)
    configs.distributed = False
    main_workers(configs.gpu_idx, configs)

def main_workers(gpu_idx, configs):
    configs.gpu_idx = gpu_idx
    configs.device = torch.device('cuda:0' if configs.gpu_idx is None else 'cuda:{}'.format(configs.gpu_idx))
    configs.subdivisions = int(64/configs.batch_size)
    configs.is_master_node = True
    tb_writer = None
    scheduler_list = ['multi_step', 'cosin', 'one_cycle']

    if configs.is_master_node:
        tb_writer = SummaryWriter(log_dir=os.path.join(configs.logs_dir, 'tensorboard'))
    model = create_model(configs)

    if configs.pretrain_path is not None:
        assert os.path.isfile(configs.pretrained_path), "No pretrain weight found!"
        model.load_state_dict(torch.load(configs.pretrained_path, map_location = "cpu"))

    if configs.resume_path is not None:
        assert os.path.isfile(configs.resume_path), "no resume checkpoint available!"
        model.load_state_dict(torch.load(configs.resume_path, map_location="cpu"))

    model = make_data_parallel(model, configs)
    optimizer = create_optimizer(configs, model)
    lr_scheduler = create_lr_scheduler(optimizer, configs)

    if configs.resume_path is not None:
        utils_path = configs.resume_path.replace("Model_", "Utils_")
        assert os.path.isfile(utils_path), "No opt checkpoint exists!"
        utils_state_dict = torch.load(utils_path, map_location='cpu')
        optimizer.load_state_dict(utils_state_dict['optimizer'])
        lr_scheduler.load_state_dict(utils_state_dict['lr_scheduler'])
        configs.start_epoch = utils_state_dict['epoch'] + 1

    train_dataloader, train_sampler = create_train_dataloader(configs)

    if configs.evaluate:
        val_dataloader = create_val_dataloader(configs)
        val_loss  = validate(val_dataloader, model, configs)
        print("val loss : {:.4e}".format(val_loss))
        return

    for epoch in range(configs.start_epoch, configs.num_epochs+1):
        if configs.distributed:
            train_sampler.set_epoch(epoch)
        train_one_epoch(train_dataloader, model, optimizer, lr_scheduler, epoch, configs,
                        logger = None, tb_writer=tb_writer)
        if (not configs.no_val) and (epoch % configs.checkpoint_freq == 0):
            val_dataloader = create_val_dataloader(configs)
            print("number of batches in val dataloader: {}".format(len(val_dataloader)))
            val_loss = validate(val_dataloader, model, configs)
            print("val_loss: {:.4e}".format(val_loss))
            if tb_writer is not None:
                tb_writer.add_scalar('Val_loss', val_loss, epoch)
        if configs.is_master_node and ((epoch % configs.checkpoint_freq)==0):
            model_state_dict, utils_state_dict = get_saved_state(model, optimizer, lr_scheduler, epoch, configs)
            save_checkpoint(configs.checkpoints_dir, configs.saved_fn, model_state_dict, utils_state_dict, epoch)

        if not configs.step_lr_in_epoch:
            lr_scheduler.step()
            if tb_writer is not None:
                tb_writer.add_scalar('LR', lr_scheduler.get_lr()[0], epoch)

    if tb_writer:
        tb_writer.close()


def train_one_epoch(train_dataloader, model, optimizer, lr_scheduler, epoch, configs,
                        logger = None, tb_writer = None):
    batch_time = AverageMeter('Time', ':6.3f')
    data_time = AverageMeter("Data", ':6.3f')
    losses = AverageMeter("Loss", ":.4e")

    progress = ProgressMeter(len(train_dataloader), [batch_time, data_time, losses],
                             prefix="Train - Epoch : [{}/{}]".format(epoch, configs.num_epochs)
                             )
    criterion = Compute_Loss()
    num_iters_per_epoch = len(train_dataloader)

    model.train()
    start_time = time.time()
    for batch_idx, batch_data in enumerate(tqdm(train_dataloader)):
        data_time.update(time.time() - start_time)
        metadatas, imgs, targets = batch_data
        batch_size = imgs.size(0)
        global_steps = num_iters_per_epoch * (epoch - 1) + batch_idx + 1
        for k in targets.keys():
            targets[k] = targets[k].to(configs.device, non_blocking = True)
        imgs = imgs.to(configs.device, non_blocking=True).float()
        outputs = model(imgs)
        total_loss, loss_stats = criterion(outputs, targets)
        if (not configs.distributed) and (configs.gpu_idx is None):
            total_loss = torch.mean(total_loss)
        total_loss.backward()

        if global_steps % configs.subdivisions == 0:
            optimizer.step()
            optimizer.zero_grad()
            if configs.step_lr_in_epoch:
                lr_scheduler.step()
                if tb_writer is not None:
                    tb_writer.add_scalar('LR', lr_scheduler.get_lr()[0], global_steps)

        if configs.distributed:
            reduced_loss = reduce_tensor(total_loss.data, configs.world_size)
        else:
            reduced_loss = total_loss.data

        losses.update(to_python_float(reduced_loss), batch_size)
        batch_time.update(time.time()-start_time)

        if tb_writer is not None:
            if (global_steps % configs.tensorboard_freq) == 0:
                loss_stats['avg_loss'] = losses.avg
                tb_writer.add_scalar("Train", loss_stats, global_steps)

        if logger is not None:
            if (global_steps % configs.print_freq) == 0:
                logger.info(progress.get_message(batch_idx))
        start_time = time.time()



def validate(val_dataloader, model, configs):
    losses = AverageMeter('Loss', ":.4e")
    criterion = Compute_Loss(device = configs.device)
    model.eval()

    with torch.no_grad():
        for batch_idx, batch_data in enumerate(tqdm(val_dataloader)):
            metadatas, imgs, targets = batch_data
            batch_size = imgs.size(0)
            for k in targets.keys():
                targets[k] = targets[k].to(configs.device, non_blocking=True)
            imgs = imgs.to(configs.device, non_blocking=True)
            outputs = model(imgs)
            total_loss, loss_stats = criterion(outputs, targets)
            if (not configs.distributed) and (configs.gpu_idx is None):
                total_loss = torch.mean(total_loss)

            if configs.distributed:
                reduce_loss = reduce_tensor(total_loss.data, configs.world_size)
            else:
                reduce_loss = total_loss.data

            losses.update(to_python_float(reduce_loss), batch_size)
    return losses.avg

if __name__ == "__main__":
    main()



