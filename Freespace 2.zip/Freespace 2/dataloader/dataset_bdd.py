import torch.utils.data as data
import torchvision.transforms as transforms
import torch
import os
import glob
import cv2
import numpy as np
import matplotlib.pyplot as plt
from parsers.parser import basic_parser, apply_parser
from PIL import Image

def flip_aug(img, label):
    isflip = np.random.randint(0,2)
    flip_img, flip_label = None, None
    if isflip:
        flip_img = img[:,::-1]
        flip_label = label[:,::-1]
        return flip_img, flip_label
    return img, label

def rotate_aug(img, label, degree=15):
    height, width = img.shape[:2]
    isrotate = np.random.randint(0,2)
    rotate_img, rotate_label = None, None
    if isrotate:
        matRotation = cv2.getRotationMatrix2D((width//2,height//2),degree,1)
        rotation_img = cv2.warpAffine(img, matRotation, (width, height), borderValue = (0,0,0))
        rotation_label = cv2.warpAffine(label, matRotation, (width, height), borderValue = (0,0,0))
#         return rotate_img, rotate_label
        return rotation_img, rotation_label
    return img,label

class freespace_bdd(data.Dataset):
    def __init__(self, opt):
        super(freespace_bdd, self).__init__()
        self.image_list = []
        #         self.root = opt['dataroot']
        #         self.image_affix = opt['image_affix']
        #         self.label_affix = opt['label_affix']
        #         self.mode = opt['phase']
        #         self.opt = opt
        #         self.batch_size = opt['batch_size']
        #         self.compact_size = (opt['useWidth'], opt['useHeight'])
        self.root = opt.dataroot
        self.image_affix = opt.image_type
        self.label_affix = opt.label_type
        self.mode = opt.mode
        self.opt = opt
        self.batch_size = opt.batch_size
        self.compact_size = (opt.Width, opt.Height)
        self.num_labels = 2
        self.mean = [0.485, 0.456, 0.406]
        self.std = [0.229, 0.224, 0.225]
        self._assertValid()

    def _assertValid(self):
        assert self.compact_size[0] % 32 == 0 and self.compact_size[
            1] % 32 == 0, "Input size should be dividable by factor of 32!"
        if self.mode == "train":
            self.image_list = sorted(glob.glob(os.path.join(self.root, "train", '*.' + self.image_affix)))
        elif self.mode == 'val':
            self.image_list = sorted(glob.glob(os.path.join(self.root, 'val', '*.' + self.image_affix)))
        else:
            self.image_list = sorted(glob.glob(os.path.join(self.root, 'test', '*.' + self.image_affix)))
        assert os.path.exists(self.root.replace("images/data", "drivable_maps/labels")), "label folder does not exist!"
        assert len(self.image_list) > 0, "Not able to locate image data"

    def __getitem__(self, index):
        #         print(self.image_list[index])
        prefix = "/".join(self.image_list[index].replace("images/data", "drivable_maps/labels").split("/")[:-1])
        #         print(prefix)
        img_name = self.image_list[index].split("/")[-1]
        #         print(img_name)
        img_name = img_name.replace("." + self.image_affix, "") + "_drivable_id." + self.label_affix
        #         print(img_name)
        #         print(os.path.join(prefix, img_name))
        #         assert False
        img = cv2.imread(self.image_list[index])
        if img is None:
            return {}
        color_image = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        height, width, depth = color_image.shape
        if self.mode.lower() in ["train", "val"]:
            label = cv2.imread(os.path.join(prefix, img_name), cv2.COLOR_BGR2RGB)
            label[label > 0] = 1

        ## data augmentation
        # color_image -> (B,H,W,C)
        # compact_color_image -> (B,C,H,W)
        if self.mode == 'train':
            color_image, label = flip_aug(color_image, label)

            color_image, label = rotate_aug(color_image, label)
            #             if color_image is None or label is None:
            #                 return {}
            compact_color_image = cv2.resize(color_image, self.compact_size, interpolation=cv2.INTER_CUBIC)
            compact_color_image = Image.fromarray(compact_color_image)
            compact_color_image = transforms.ColorJitter(brightness=30, contrast=10, saturation=0, hue=0)(
                compact_color_image)
            compact_color_image = transforms.ToTensor()(compact_color_image)
            compact_color_image = transforms.Normalize(mean=self.mean, std=self.std)(compact_color_image)

            compact_label = cv2.resize(label, self.compact_size, interpolation=cv2.INTER_CUBIC)
            compact_label[compact_label > 0] = 1
            compact_label = torch.from_numpy(compact_label)
            compact_label = compact_label.type(torch.LongTensor)
        else:
            compact_color_image = cv2.resize(color_image, self.compact_size, interpolation=cv2.INTER_CUBIC)
            compact_color_image = Image.fromarray(compact_color_image)
            compact_color_image = transforms.ToTensor()(compact_color_image)
            compact_label = cv2.resize(label, self.compact_size, interpolation=cv2.INTER_CUBIC)
            compact_label[compact_label > 0] = 1
            compact_label = torch.from_numpy(compact_label)
            compact_label = compact_label.type(torch.LongTensor)

        return {'rgb_image': compact_color_image, 'label': compact_label,
                "oriSize": (width, height), 'path': os.path.join(prefix, img_name)}

    def __len__(self):
        return len(self.image_list)


if __name__ == "__main__":
    opt = basic_parser()
    opt = apply_parser(opt)
    print(opt)
    dataset = freespace_bdd(opt)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=True)
    for idx, item in enumerate(dataloader):
        if len(item) == 0:
            print("one item skiped!")
            continue
        color_image, label, oriSize, path = item['rgb_image'], item['label'], item['oriSize'], item['path']
        color_image = color_image.numpy()
        label = label.numpy()
        color_image = np.squeeze(color_image, axis=0)
        label = np.squeeze(label)
        color_image = np.transpose(color_image, (1, 2, 0))
        #         label = np.transpose(label, (1,2,0))
        plt.imshow(color_image, alpha=0.5)
        plt.imshow(label, alpha=0.5)
        plt.pause(0.1)
        plt.axis('off')
        plt.clf()
