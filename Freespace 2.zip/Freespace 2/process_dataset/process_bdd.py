import os
from glob import glob
import tqdm
import cv2

if __name__ == "__main__":
    mode = "train"  # mode -> train/val/test
    image_affix, label_affix = "jpg", "png"
    root = os.path.join("..", "datasets")
    image_path = os.path.join(root, "images", mode, "*." + image_affix)
    color_label = os.path.join(root, "drivable_maps", mode, "*." + label_affix)

    image_lists = sorted(glob(image_path))
    color_lists = sorted(glob(color_label))

    target_image_folder = os.path.join("..", "datasets", "Bdd", mode, "images_2")
    target_gt_folder = os.path.join("..", "datasets", "Bdd", mode, "gt_images_2")
    if not os.path.exists(target_image_folder):
        os.makedirs(target_image_folder, exist_ok=False)
        os.makedirs(target_gt_folder, exist_ok=False)

    for img, label in zip(image_lists, color_lists):
        if img.split("/")[-1].replace("."+image_affix, "") == label.split("/")[-1].replace("_drivable_color."+label_affix, ""):
            os.rename(img, os.path.join(target_image_folder, img.split("/")[-1]))
            os.rename(label, os.path.join(target_gt_folder, label.split("/")[-1]))


