import argparse
import os


def basic_parser():
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--dataroot', default=os.path.join(".", "datasets", "Bdd"),
                        help='path to images, should have training, validation and testing')
    parser.add_argument('--image-type', default="jpg",
                        help="What's the type of the image? (for example png)")
    parser.add_argument('--label-type', default="png",
                        help="What's the type of the label? (for example png)")
    parser.add_argument('--label-number', type=int, default=2,
                        help="How many labels involved? (for example 2)")
    parser.add_argument('--backbone-type', type=int, default=50,
                        help="Only available for Resnet, 18,34,50,101,152")
    parser.add_argument('--Width', type=int, default=1280, help='The width of input image')
    parser.add_argument('--Height', type=int, default=736, help='The height of input image')
    parser.add_argument('--epoch', type=int, default=0, help='The epoch to start')
    parser.add_argument('--mode', type=str, default="train", help='Are you working on train/val/test set?')
    parser.add_argument('--batch_size', type=int, default=1, help='The batchsize for current dataset')
    parser.add_argument('--seed', type=int, default=2020, help='Provide seed for reproduction purpose')
    parser.add_argument('--checkpoint', type=str, default="./checkpoint", help='The checkpoint folder')
    parser.add_argument('--print_freq', type=int, default=10, help='How frequent to print out info')
    parser.add_argument('--gpu', type=str, default=None, help='Which gpu to use? e.g. 0,1,2,3')
    parser.add_argument('--istrain', action='store_false', help='Currently in training mode or not')
    parser.add_argument('--optimizer', type = str, default = "sgd", help='Select optimizer you want to use for now')
    parser.add_argument('--continue_train', action="store_true", help='whether you need to restart training')
    return parser


def train_parser():
    parser = basic_parser()
    parser.add_argument('--lr', type=float, default=0.001, help='initial learning rate for optimizer')
    parser.add_argument('--momentum', type=float, default=0.9, help='momentum factor for SGD')
    parser.add_argument('--weight_decay', type=float, default=0.0005, help='momentum factor for optimizer')
    parser.add_argument('--lr_decay_iters', type=int, default=5000000,
                        help='multiply by a gamma every lr_decay_iters iterations')
    parser.add_argument('--lr_decay_epochs', type=int, default=25,
                        help='multiply by a gamma every lr_decay_epoch epochs')
    parser.add_argument('--lr_gamma', type=float, default=0.9, help='gamma factor for lr_scheduler')
    parser.add_argument('--lambda_L1', type=float, default=100.0, help='weight for L1 loss')
    parser.add_argument('--scheduler_type', type=str, default='lambda',
                        help='learning rate policy: currently support lambda or step')
    parser.add_argument('--max_epoch', type=int, default=150,
                        help='Max epochs applied to training task')
    return parser


def validation_parser():
    parser = basic_parser()
    parser.add_argument('--lr', type=float, default=0.001, help='initial learning rate for optimizer')
    parser.add_argument('--momentum', type=float, default=0.9, help='momentum factor for SGD')
    parser.add_argument('--weight_decay', type=float, default=0.0005, help='momentum factor for optimizer')
    parser.add_argument('--lr_decay_iters', type=int, default=5000000,
                        help='multiply by a gamma every lr_decay_iters iterations')
    parser.add_argument('--lr_decay_epochs', type=int, default=25,
                        help='multiply by a gamma every lr_decay_epoch epochs')
    parser.add_argument('--lr_gamma', type=float, default=0.9, help='gamma factor for lr_scheduler')
    parser.add_argument('--lambda_L1', type=float, default=100.0, help='weight for L1 loss')
    parser.add_argument('--scheduler_type', type=str, default='lambda',
                        help='learning rate policy: currently support lambda or step')
    parser.add_argument('--max_epoch', type=int, default=150,
                        help='Max epochs applied to training task')
    return parser

def test_parser():
    parser = basic_parser()
    parser.add_argument('--output_folder', type = str, default = "output", help='The output folder to save data')
    parser.mode = "test"
    return parser

def summarize_parser(args):
    print("-" * 10 + "Here is the summary of the available parameters:" + "-" * 10)
    if not os.path.exists(args.checkpoint):
        os.makedirs(args.checkpoint, exist_ok=False)
    with open(os.path.join(args.checkpoint, "conf.txt"), "w") as file_writer:
        for arg in vars(args):
            v = getattr(args, arg)
            if v is None:
                v = ""
            if isinstance(v, list):
                v = str(v)
            para = "Input parameter: {:<25} The value: {:<25}".format(arg, v)
            print(para)
            file_writer.writelines(para + "\n")
        print("-" * 10 + "End of the summary" + "-" * 10)



def apply_parser(args):
    args = args.parse_args()
    args.num_labels = args.label_number
    args.num_layer = args.backbone_type
    if args.gpu:
        if "," in args.gpu:
            args.gpu = list(map(int, args.gpu.split(",")))
        elif len(args.gpu) == 1:
            args.gpu = int(args.gpu)
    return args

