import cv2
import os

image_folder = "./examples/overlay"
pred_video_name = 'inference_video.mp4'
fourcc = cv2.VideoWriter_fourcc('m', 'p', '4', 'v')
affix = "jpg"

images = [img for img in os.listdir(image_folder) if img.endswith(affix)]
images.sort()

frame = cv2.imread(os.path.join(image_folder, images[0]))
height, width, layers = frame.shape

pred_video = cv2.VideoWriter(pred_video_name, fourcc, 9, (width,height))

for image in images:
    pred_video.write(cv2.imread(os.path.join(image_folder, image)))

cv2.destroyAllWindows()
pred_video.release()
print("Complete!")