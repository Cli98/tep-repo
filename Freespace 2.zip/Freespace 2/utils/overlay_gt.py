import matplotlib.pyplot as plt
import os
import numpy as np
import matplotlib
matplotlib.use('Agg')
from PIL import Image

source_img_folder = os.path.join(".", "examples", "source")
pred_img_folder = os.path.join(".", "examples", "pred")
gt_img_folder = os.path.join(".", "examples", "gt")
affix = "jpg"
rgb_image_list = [os.path.join(source_img_folder, img) for img in os.listdir(source_img_folder)
                  if img.endswith(affix)]
pred_image_list = [os.path.join(pred_img_folder, pred) for pred in os.listdir(pred_img_folder)
                   if pred.endswith(affix)]
gt_image_list = []
if os.path.exists(gt_img_folder):
    gt_image_list = [os.path.join(gt_img_folder, gt) for gt in os.listdir(gt_img_folder)
                     if gt.endswith(affix)]
rgb_image_list.sort()
pred_image_list.sort()
gt_image_list.sort()
assert len(rgb_image_list) == len(pred_image_list), "the number between rgb and prediction images are not same!"

os.makedirs(os.path.join(".", "examples", "overlay"), exist_ok=False)
os.makedirs(os.path.join(".", "examples", "overlay_gt"), exist_ok=False)

for rgb_image_pth, pred_image_pth in zip(rgb_image_list, pred_image_list):
    img = Image.open(rgb_image_pth)
    pred = Image.open(pred_image_pth)
    blended = Image.blend(img, pred, alpha=0.3)
    blended.save(rgb_image_pth.replace("source", "overlay"))
    # plt.imshow(img)
    # plt.imshow(pred, alpha=0.3)
    # plt.axis('off')
    # plt.savefig(rgb_image_pth.replace("source", "overlay"), bbox_inches='tight', pad_inches=0)

for rgb_image_pth, gt_image_path in zip(rgb_image_list, gt_image_list):
    img = plt.imread(rgb_image_pth)
    gt_ori = plt.imread(gt_image_path)
    gt = np.zeros(gt_ori.shape)
    gt[gt_ori[:, :, 2] > 0, 2] = 128
    plt.imshow(img)
    plt.imshow(gt, alpha=0.3)
    plt.axis('off')
    plt.savefig(rgb_image_pth.replace("source", "overlay_gt"), bbox_inches='tight', pad_inches=0)
